Tests Created by Evyatar.
Tests for nand2tetris, project 7.

'AllTogether' contains all other tests.
The small tests are here to make debugging  easier.